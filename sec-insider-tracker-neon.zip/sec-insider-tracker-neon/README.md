# SEC Form 4 — Insider Trading Tracker

Live dashboard for SEC Form 4 insider trading filings.
GitHub Pages frontend + Neon Postgres backend + Python ingestion cron.

---

## Architecture

```
GitHub Pages  (static HTML/React/CSS — this repo)
      │
      │  reads from
      ▼
 Neon Postgres  (free, serverless, never pauses)
      ▲
      │  writes to
 db/fetch_filings.py  (Python cron — runs daily)
      ▲
      │  fetches from
 SEC EDGAR  (public API, free)
```

---

## Full setup — three stages

### Stage 1 — GitHub Pages (5 min, no database yet)

The site works immediately in demo mode with realistic fake data.

1. Push this repo to GitHub
2. **Settings → Pages → Source → GitHub Actions**
3. Push any commit to `main` — the Actions workflow deploys automatically
4. Visit `https://<username>.github.io/<repo>/`

---

### Stage 2 — Neon database (15 min)

**Why Neon?** Free tier, never pauses (unlike Supabase which pauses after 7 days),
pure Postgres, up to 100 free projects, no credit card needed.

#### 2a. Create a Neon project

1. Sign up at [neon.tech](https://neon.tech) (free, no card)
2. Create a new project — name it `sec-insider-tracker`
3. Note your **Project ID** (shown in the URL: `console.neon.tech/app/projects/ep-xxx`)

#### 2b. Run the SQL migration

1. In Neon Console, open the **SQL Editor**
2. Paste the entire contents of `db/migrations/001_create_filings.sql`
3. Click **Run** — this creates the `filings` table, indexes, and views

#### 2c. Set up your environment

```bash
cd db
cp .env.example .env
# now edit db/.env with your values (see comments inside)
```

The only required fields:
```env
DATABASE_URL=postgresql://neondb_owner:PASSWORD@ep-XXXX-pooler.us-east-2.aws.neon.tech/neondb?sslmode=require
USER_AGENT_EMAIL=your@email.com
```

Get `DATABASE_URL` from: Neon Console → your project → **Connection Details** →
select **Pooled connection** → copy the connection string.

#### 2d. Install Python deps and test

```bash
pip install "psycopg[binary]" requests python-dotenv

# Dry run first — parses EDGAR XML but does NOT write to DB
DRY_RUN=1 python fetch_filings.py

# When the sample row looks good, run for real
python fetch_filings.py
```

Expected output:
```
09:14:02  INFO     SEC Form 4 → Neon Postgres Ingestion
09:14:02  INFO     Range    : 2025-05-12  →  2025-05-15
09:14:03  INFO     Step 1/3  Querying EDGAR EFTS…
09:14:45  INFO     Step 3/3  Upserting to Neon…
09:14:46  INFO       Batch 1: 487 rows written (487 total)
09:14:46  INFO     Done.
```

#### 2e. Connect the frontend to Neon

You need two values from Neon Console:

- **API URL**: Console → your project → the hostname shown at top  
  Format: `https://ep-XXXX.us-east-2.aws.neon.tech`
- **API Key**: Console → **Account Settings → API Keys → Create key**

Edit `src/config.js`:

```js
DATA_SOURCE:   "neon",
NEON_API_URL:  "https://ep-XXXX.us-east-2.aws.neon.tech",
NEON_API_KEY:  "your-neon-api-key",
NEON_DATABASE: "neondb",
NEON_ROLE:     "neondb_owner",
```

Commit and push. The site now reads live data from your Neon DB.

---

### Stage 3 — Daily cron (keeps data fresh automatically)

#### Option A: GitHub Actions (easiest — free, zero server needed)

Add these to your repo's **Settings → Secrets → Actions**:
- `DATABASE_URL` — your Neon pooled connection string
- `USER_AGENT_EMAIL` — your email

Create `.github/workflows/ingest.yml`:

```yaml
name: Daily Form 4 Ingestion

on:
  schedule:
    - cron: '0 23 * * 1-5'   # weekdays 6 PM ET
  workflow_dispatch:           # allows manual run from Actions tab

jobs:
  ingest:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      - run: pip install "psycopg[binary]" requests python-dotenv
      - run: python db/fetch_filings.py
        env:
          DATABASE_URL:      ${{ secrets.DATABASE_URL }}
          USER_AGENT_EMAIL:  ${{ secrets.USER_AGENT_EMAIL }}
          DAYS_BACK:         3
```

#### Option B: Local cron

```cron
# Weekdays at 6 PM ET (adjust for your timezone)
0 23 * * 1-5 cd /path/to/project/db && python fetch_filings.py >> fetch.log 2>&1
```

---

## Backfilling historical data

```bash
# Last 90 days
START_DATE=2025-02-15 END_DATE=2025-05-15 python db/fetch_filings.py

# Full year — run in chunks to stay polite with EDGAR
START_DATE=2025-01-01 END_DATE=2025-03-31 python db/fetch_filings.py
START_DATE=2025-04-01 END_DATE=2025-05-15 python db/fetch_filings.py
```

---

## File structure

```
sec-insider-tracker/
├── index.html
├── src/
│   ├── config.js          ← ⭐ edit this to switch data sources
│   ├── edgar.js           ← fetch + enrich layer (Neon / proxy / demo)
│   ├── app.jsx            ← React UI
│   └── style.css
├── db/
│   ├── fetch_filings.py   ← Python ingestion (EDGAR XML → Neon Postgres)
│   ├── .env.example       ← copy to .env and fill in
│   └── migrations/
│       └── 001_create_filings.sql
├── worker/
│   ├── index.js           ← optional Cloudflare Worker CORS proxy
│   └── wrangler.toml
└── .github/workflows/
    ├── deploy.yml         ← auto-deploys GitHub Pages on push to main
    └── ingest.yml         ← (create this) daily cron job
```

---

## Neon free tier

| | |
|---|---|
| Projects | up to 100 |
| Storage per project | 0.5 GB |
| Compute | 100 CU-hours/project/month |
| Pauses after inactivity | Never — scales to zero, wakes in ~300ms |
| Credit card required | No |

0.5 GB holds roughly 5–10 years of Form 4 transactions
(each row ~500 bytes; ~100k filings/year × ~2 transactions avg = ~100 MB/year).
