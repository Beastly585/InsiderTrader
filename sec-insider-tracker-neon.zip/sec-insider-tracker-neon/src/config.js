// ─────────────────────────────────────────────────────────────────────────────
// config.js  — edit this file to change your data source
// ─────────────────────────────────────────────────────────────────────────────

window.APP_CONFIG = {

  // ── Data source ────────────────────────────────────────────────────────────
  // Options: "neon" | "proxy" | "demo"
  //
  //  "demo"  → built-in realistic fake data. No setup. Great for previewing.
  //
  //  "proxy" → Cloudflare Worker proxies live SEC EDGAR filings (metadata only).
  //            Free, ~100k req/day. Deploy worker/index.js, paste URL below.
  //
  //  "neon"  → reads from your Neon Postgres via their HTTP Data API.
  //            Full transaction data (shares, price, value). Best option.
  //            Run db/fetch_filings.py to populate, paste connection below.
  //
  DATA_SOURCE: "demo",   // ← change to "neon" once your DB is populated

  // ── Cloudflare Worker proxy (DATA_SOURCE = "proxy") ────────────────────────
  PROXY_URL: "https://YOUR-WORKER.YOUR-SUBDOMAIN.workers.dev",

  // ── Neon (DATA_SOURCE = "neon") ────────────────────────────────────────────
  // From Neon Console → your project → Connection Details
  // Use the HTTP/Data API endpoint, NOT the connection string.
  // Neon Console → "Connect" → toggle to "HTTP" tab → copy the fetch snippet
  NEON_API_URL:  "https://YOUR-PROJECT-ID.us-east-2.aws.neon.tech",
  NEON_API_KEY:  "your-neon-api-key-here",   // Neon Console → Account → API Keys
  NEON_DATABASE: "neondb",                   // default DB name (change if different)
  NEON_ROLE:     "neondb_owner",             // default role (change if different)

  // ── Pagination ─────────────────────────────────────────────────────────────
  PAGE_SIZE: 25,

  // ── How many days back to show by default ─────────────────────────────────
  DEFAULT_DAYS_BACK: 14,
};
