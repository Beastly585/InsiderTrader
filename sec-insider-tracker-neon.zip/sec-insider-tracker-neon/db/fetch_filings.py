#!/usr/bin/env python3
"""
db/fetch_filings.py
─────────────────────────────────────────────────────────────────────────────
Full SEC Form 4 ingestion pipeline — writes to Neon (or any Postgres).
No Supabase SDK required; uses standard psycopg (psycopg3) or psycopg2.

Pipeline:
  1. Query EDGAR EFTS for Form 4 accession numbers in a date range
  2. Resolve each accession → filing index page → primary XML URL
  3. Download + parse each Form 4 XML (non-derivative + derivative tables)
  4. Upsert all transactions into Postgres via a single COPY / INSERT ON CONFLICT

Run manually:
    cd db
    python fetch_filings.py

Dry-run (parse but don't write):
    DRY_RUN=1 python fetch_filings.py

Backfill a date range:
    START_DATE=2025-01-01 END_DATE=2025-05-15 python fetch_filings.py

Cron (weekdays 6 PM ET):
    0 23 * * 1-5 cd /path/to/project/db && python fetch_filings.py >> fetch.log 2>&1

Requirements:
    pip install psycopg[binary] requests python-dotenv
    # If psycopg3 unavailable: pip install psycopg2-binary requests python-dotenv

Environment (db/.env):
    DATABASE_URL       postgresql://user:pass@host/db?sslmode=require
    USER_AGENT_EMAIL   your@email.com
    DAYS_BACK          3
    MAX_WORKERS        6
    DRY_RUN            0
    START_DATE         (optional override)
    END_DATE           (optional override)
─────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

import os
import re
import sys
import time
import json
import logging
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict
from datetime import date, timedelta
from typing import Optional
from pathlib import Path
from io import StringIO

import requests
from dotenv import load_dotenv

# ── Bootstrap ──────────────────────────────────────────────────────────────────

load_dotenv(Path(__file__).parent / ".env")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger(__name__)

# ── Config ─────────────────────────────────────────────────────────────────────

DATABASE_URL     = os.environ.get("DATABASE_URL", "")
USER_AGENT_EMAIL = os.environ.get("USER_AGENT_EMAIL", "your@email.com")
DAYS_BACK        = int(os.environ.get("DAYS_BACK", "3"))
MAX_WORKERS      = int(os.environ.get("MAX_WORKERS", "6"))
DRY_RUN          = os.environ.get("DRY_RUN", "0") == "1"
START_DATE_OVERRIDE = os.environ.get("START_DATE")
END_DATE_OVERRIDE   = os.environ.get("END_DATE")

EDGAR_EFTS_URL = "https://efts.sec.gov/LATEST/search-index"
EDGAR_BASE_URL = "https://www.sec.gov"
HEADERS = {
    "User-Agent":      f"insider-tracker/2.0 ({USER_AGENT_EMAIL})",
    "Accept-Encoding": "gzip, deflate",
    "Accept":          "application/json, text/html, application/xml",
}
POLITE_SLEEP = 0.12  # seconds between requests

# ── DB connection (prefers psycopg3, falls back to psycopg2) ──────────────────

def get_connection():
    try:
        import psycopg
        return psycopg.connect(DATABASE_URL)
    except ImportError:
        import psycopg2
        return psycopg2.connect(DATABASE_URL)

# ── Static lookup tables ───────────────────────────────────────────────────────

SECTOR_MAP: dict[str, list[str]] = {
    "Technology": [
        "AAPL","MSFT","GOOGL","GOOG","META","NVDA","AMZN","TSLA","INTC","AMD",
        "ORCL","CRM","ADBE","QCOM","TXN","AVGO","NOW","SNOW","PLTR","IBM",
        "CSCO","ACN","SAP","INTU","SHOP","UBER","LYFT","RBLX","COIN","DDOG",
        "ZS","PANW","CRWD","NET","MDB","OKTA","TWLO","U","GTLB","HUBS",
    ],
    "Finance": [
        "JPM","BAC","WFC","GS","MS","C","BLK","AXP","V","MA","SCHW",
        "USB","PNC","TFC","COF","SPGI","MCO","ICE","CME","CBOE","AFL",
        "MET","PRU","ALL","TRV","HIG","WRB","AIG","BX","KKR","APO","CG",
    ],
    "Healthcare": [
        "JNJ","PFE","UNH","ABBV","MRK","LLY","BMY","AMGN","GILD","CVS",
        "MDT","ABT","TMO","DHR","ISRG","REGN","VRTX","BIIB","BSX","EW",
        "IQV","A","BIO","ZBH","SYK","BAX","DXCM","ILMN","IDXX","MTD",
    ],
    "Energy": [
        "XOM","CVX","COP","SLB","PSX","EOG","MPC","VLO","PXD","OXY",
        "HES","DVN","FANG","MRO","APA","HAL","BKR","NOV","WMB","KMI",
        "ET","EPD","LNG","CQP","TRGP","AM","CTRA","SM","PR","MTDR",
    ],
    "Consumer Staples": [
        "WMT","PG","KO","PEP","COST","PM","MO","CL","GIS","KHC",
        "HSY","MKC","SJM","CAG","CPB","K","HRL","TSN","ADM","BG",
    ],
    "Consumer Discretionary": [
        "AMZN","HD","MCD","NKE","SBUX","LOW","TGT","TJX","EBAY","ETSY",
        "ROST","BKNG","ABNB","MAR","HLT","YUM","CMG","DPZ","DKNG","WYNN",
        "LVS","MGM","RCL","CCL","NCLH","PHM","DHI","LEN","TOL","NVR",
    ],
    "Industrials": [
        "HON","UNP","BA","CAT","GE","MMM","DE","EMR","ETN","ITW",
        "LMT","RTX","NOC","GD","HII","TDG","FDX","UPS","DAL","UAL",
        "AAL","NSC","CSX","WAB","PCAR","CMI","PH","ROK","DOV","XYL",
    ],
    "Real Estate": [
        "AMT","PLD","EQIX","CCI","SPG","O","WELL","DLR","PSA","EXR",
        "ARE","VTR","BXP","SLG","KIM","REG","FRT","EQR","AVB","ESS",
    ],
    "Utilities": [
        "NEE","DUK","SO","AEP","EXC","SRE","PCG","ED","FE","EIX",
        "XEL","WEC","ES","ETR","PPL","CNP","NI","AES","AWK","CMS",
    ],
    "Communication Services": [
        "META","GOOGL","NFLX","DIS","VZ","T","CMCSA","TMUS","EA","TTWO",
        "MTCH","IAC","WBD","PARA","FOXA","NYT","SNAP","PINS","RDDT","SPOT",
    ],
    "Materials": [
        "LIN","APD","ECL","SHW","FCX","NEM","NUE","VMC","MLM","DD",
        "DOW","PPG","RPM","ALB","CF","MOS","FMC","CE","EMN","IFF",
    ],
}

TICKER_SECTOR: dict[str, str] = {t: s for s, ts in SECTOR_MAP.items() for t in ts}

TX_CODE_MAP: dict[str, str] = {
    "P": "Open Market Purchase",
    "S": "Open Market Sale",
    "A": "Grant / Award",
    "D": "Return to Issuer",
    "F": "Tax Withholding (Sale)",
    "G": "Gift",
    "I": "Discretionary Transaction",
    "J": "Other",
    "K": "Equity Swap",
    "L": "Small Acquisition (<$10k)",
    "M": "Exercise of Derivative",
    "O": "Exercise of Out-of-Money Option",
    "U": "Tender of Shares",
    "W": "Inheritance",
    "X": "Exercise of In-the-Money Option",
    "Z": "Deposit / Withdrawal (Voting Trust)",
    "C": "Conversion of Derivative",
    "E": "Expiration of Short Derivative",
    "H": "Expiration of Long Derivative",
}

# ── Helpers ────────────────────────────────────────────────────────────────────

def get_sector(ticker: Optional[str]) -> str:
    return TICKER_SECTOR.get((ticker or "").upper().strip(), "Other")

def get_relationship(title: str, is_officer: bool, is_director: bool, is_ten: bool) -> str:
    t = (title or "").lower()
    if is_officer or re.search(r"chief|ceo|cfo|coo|cto|ciso|president|exec[\s.]?v", t):
        return "strong"
    if re.search(r"\bsvp\b|\bevp\b|senior v|managing dir|general counsel|treasurer|secretary", t):
        return "medium"
    return "weak"

def safe_float(val: Optional[str]) -> Optional[float]:
    if val is None:
        return None
    try:
        return float(str(val).replace(",", "").strip())
    except (ValueError, TypeError):
        return None

def xtxt(el: Optional[ET.Element], *tags: str) -> Optional[str]:
    """Walk XML tags and return leaf text."""
    cur = el
    for tag in tags:
        if cur is None:
            return None
        cur = cur.find(tag)
    if cur is None or not cur.text:
        return None
    return cur.text.strip()

# ── Data model ─────────────────────────────────────────────────────────────────

# Column order matches the INSERT statement below
COLUMNS = [
    "accession_number", "cik",
    "company_name", "ticker", "cik_issuer",
    "insider_name", "insider_cik", "insider_title",
    "is_director", "is_officer", "is_ten_pct_owner",
    "filing_date", "transaction_date",
    "transaction_type", "transaction_code", "transaction_code_label",
    "is_derivative",
    "security_title", "shares", "price_per_share", "value",
    "shares_owned_after", "direct_ownership",
    "relationship", "sector",
    "footnotes",
]

@dataclass
class Transaction:
    accession_number:       str
    cik:                    str
    company_name:           Optional[str]   = None
    ticker:                 Optional[str]   = None
    cik_issuer:             Optional[str]   = None
    insider_name:           Optional[str]   = None
    insider_cik:            Optional[str]   = None
    insider_title:          Optional[str]   = None
    is_director:            bool            = False
    is_officer:             bool            = False
    is_ten_pct_owner:       bool            = False
    filing_date:            Optional[str]   = None
    transaction_date:       Optional[str]   = None
    transaction_type:       Optional[str]   = None
    transaction_code:       Optional[str]   = None
    transaction_code_label: Optional[str]   = None
    is_derivative:          bool            = False
    security_title:         Optional[str]   = None
    shares:                 Optional[float] = None
    price_per_share:        Optional[float] = None
    value:                  Optional[float] = None
    shares_owned_after:     Optional[float] = None
    direct_ownership:       bool            = True
    relationship:           Optional[str]   = None
    sector:                 Optional[str]   = None
    footnotes:              Optional[str]   = None

    def to_tuple(self) -> tuple:
        d = asdict(self)
        for k in ("shares", "price_per_share", "value", "shares_owned_after"):
            if d[k] is not None:
                d[k] = round(d[k], 4)
        return tuple(d[c] for c in COLUMNS)

# ── EDGAR: list filings ────────────────────────────────────────────────────────

def edgar_get_accessions(start_date: str, end_date: str) -> list[dict]:
    all_hits: list[dict] = []
    offset, page_size = 0, 40
    while True:
        params = {"forms": "4", "dateRange": "custom",
                  "startdt": start_date, "enddt": end_date, "from": offset}
        try:
            resp = requests.get(EDGAR_EFTS_URL, params=params, headers=HEADERS, timeout=30)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            log.error(f"EDGAR search error at offset {offset}: {e}")
            break

        hits = data.get("hits", {}).get("hits", [])
        if not hits:
            break

        for h in hits:
            src       = h.get("_source", {})
            accession = h.get("_id", "")
            cik       = re.sub(r"^0+", "", accession.split("-")[0])
            all_hits.append({
                "accession":   accession,
                "cik":         cik,
                "file_date":   src.get("file_date") or src.get("period_of_report"),
                "entity_name": src.get("entity_name", ""),
            })

        total = data.get("hits", {}).get("total", {})
        if isinstance(total, dict):
            total = total.get("value", 0)
        log.info(f"  EFTS offset={offset}: {len(hits)} hits (range total: {total})")

        offset += page_size
        if len(hits) < page_size:
            break
        time.sleep(POLITE_SLEEP)

    return all_hits

# ── EDGAR: resolve XML URL ────────────────────────────────────────────────────

def get_xml_url(accession_raw: str, cik: str) -> Optional[str]:
    accession_nodash = accession_raw.replace("-", "")
    cik_padded       = accession_raw.split("-")[0]

    for cik_try in [cik_padded, cik]:
        url = (f"{EDGAR_BASE_URL}/Archives/edgar/data/"
               f"{cik_try}/{accession_nodash}/{accession_raw}-index.htm")
        try:
            resp = requests.get(url, headers=HEADERS, timeout=20)
            if resp.status_code == 404:
                continue
            resp.raise_for_status()
            links = re.findall(r'href="(/Archives/edgar/data/[^"]+\.xml)"',
                               resp.text, re.IGNORECASE)
            for link in links:
                fname = link.rsplit("/", 1)[-1].lower()
                if fname.endswith(".xml") and not fname.startswith("xsl") and "schema" not in fname:
                    return EDGAR_BASE_URL + link
        except Exception as e:
            log.debug(f"Index fetch [{accession_raw} cik={cik_try}]: {e}")
    return None

def fetch_xml(url: str) -> Optional[str]:
    try:
        resp = requests.get(url, headers=HEADERS, timeout=30)
        resp.raise_for_status()
        return resp.text
    except Exception as e:
        log.debug(f"XML download [{url}]: {e}")
        return None

# ── Form 4 XML Parser ─────────────────────────────────────────────────────────

def parse_form4_xml(xml_text: str, accession: str, cik: str,
                    fallback_date: Optional[str] = None,
                    fallback_company: Optional[str] = None) -> list[Transaction]:
    xml_text = xml_text.strip().lstrip("\ufeff")
    if not xml_text.startswith("<"):
        start = xml_text.find("<")
        if start == -1:
            return []
        xml_text = xml_text[start:]

    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as e:
        log.warning(f"XML parse error [{accession}]: {e}")
        return []

    # Footnotes
    footnotes: dict[str, str] = {}
    fn_sec = root.find("footnotes")
    if fn_sec is not None:
        for fn in fn_sec.findall("footnote"):
            fid = fn.get("id", "")
            if fid and fn.text:
                footnotes[fid] = fn.text.strip()

    def resolve_fn(el: Optional[ET.Element]) -> Optional[str]:
        if el is None:
            return None
        ids   = [c.text.strip() for c in el.findall("footnoteId") if c.text]
        texts = [footnotes[i] for i in ids if i in footnotes]
        return "; ".join(texts) if texts else None

    # Issuer
    issuer_el  = root.find("issuer")
    company    = xtxt(issuer_el, "issuerName") or fallback_company
    ticker_raw = xtxt(issuer_el, "issuerTradingSymbol")
    ticker     = ticker_raw.upper().strip() if ticker_raw else None
    cik_issuer = xtxt(issuer_el, "issuerCik")

    # Reporting owners
    owners_el = root.findall("reportingOwner") or root.findall(".//reportingOwner")
    parsed_owners = []
    for ow in owners_el:
        id_el  = ow.find("reportingOwnerId")
        rel_el = ow.find("reportingOwnerRelationship")
        name      = xtxt(id_el,  "rptOwnerName")
        ocik      = xtxt(id_el,  "rptOwnerCik")
        is_dir    = (xtxt(rel_el, "isDirector")         or "0") == "1"
        is_off    = (xtxt(rel_el, "isOfficer")          or "0") == "1"
        is_ten    = (xtxt(rel_el, "isTenPercentOwner")  or "0") == "1"
        title_raw = xtxt(rel_el, "officerTitle") or ""
        if not title_raw:
            parts = []
            if is_dir: parts.append("Director")
            if is_off: parts.append("Officer")
            if is_ten: parts.append("10% Owner")
            title_raw = ", ".join(parts) or "Unknown"
        parsed_owners.append({"name": name, "cik": ocik, "title": title_raw,
                               "is_dir": is_dir, "is_off": is_off, "is_ten": is_ten})

    primary = next((o for o in parsed_owners if o["is_off"]),
                   parsed_owners[0] if parsed_owners else {})
    insider_name  = primary.get("name")
    insider_cik_v = primary.get("cik")
    insider_title = primary.get("title", "Unknown")
    is_dir_v      = primary.get("is_dir", False)
    is_off_v      = primary.get("is_off", False)
    is_ten_v      = primary.get("is_ten", False)

    period = (xtxt(root, "periodOfReport")
              or xtxt(root, "period_of_report")
              or fallback_date)
    rel = get_relationship(insider_title, is_off_v, is_dir_v, is_ten_v)

    def base() -> dict:
        return dict(
            accession_number = accession,
            cik              = cik,
            company_name     = company,
            ticker           = ticker,
            cik_issuer       = cik_issuer,
            insider_name     = insider_name,
            insider_cik      = insider_cik_v,
            insider_title    = insider_title,
            is_director      = is_dir_v,
            is_officer       = is_off_v,
            is_ten_pct_owner = is_ten_v,
            filing_date      = period,
            relationship     = rel,
            sector           = get_sector(ticker),
        )

    transactions: list[Transaction] = []

    # Non-derivative transactions
    nd_table = root.find("nonDerivativeTable")
    if nd_table is not None:
        for tx in nd_table.findall("nonDerivativeTransaction"):
            security    = xtxt(tx, "securityTitle",    "value")
            tx_date     = xtxt(tx, "transactionDate",  "value")
            coding_el   = tx.find("transactionCoding")
            tx_code     = xtxt(coding_el, "transactionCode") if coding_el is not None else None
            acq_disp    = xtxt(tx, "transactionAmounts", "transactionAcquiredDisposedCode", "value")
            shares_v    = safe_float(xtxt(tx, "transactionAmounts", "transactionShares", "value"))
            price_v     = safe_float(xtxt(tx, "transactionAmounts", "transactionPricePerShare", "value"))
            owned_after = safe_float(xtxt(tx, "postTransactionAmounts", "sharesOwnedFollowingTransaction", "value"))
            dir_indir   = xtxt(tx, "ownershipNature", "directOrIndirectOwnership", "value")
            fn_txt      = resolve_fn(tx)

            if tx_code == "P":      tx_type = "buy"
            elif tx_code == "S":    tx_type = "sell"
            elif acq_disp == "A":   tx_type = "buy"
            elif acq_disp == "D":   tx_type = "sell"
            else:                   tx_type = "other"

            value = round(shares_v * price_v, 2) if shares_v and price_v else None
            transactions.append(Transaction(
                **base(),
                transaction_date       = tx_date,
                transaction_type       = tx_type,
                transaction_code       = tx_code,
                transaction_code_label = TX_CODE_MAP.get(tx_code or "", "Other"),
                is_derivative          = False,
                security_title         = security,
                shares                 = shares_v,
                price_per_share        = price_v,
                value                  = value,
                shares_owned_after     = owned_after,
                direct_ownership       = (dir_indir or "D") == "D",
                footnotes              = fn_txt,
            ))

    # Derivative transactions
    d_table = root.find("derivativeTable")
    if d_table is not None:
        for tx in d_table.findall("derivativeTransaction"):
            security    = xtxt(tx, "securityTitle",    "value")
            tx_date     = xtxt(tx, "transactionDate",  "value")
            coding_el   = tx.find("transactionCoding")
            tx_code     = xtxt(coding_el, "transactionCode") if coding_el is not None else None
            acq_disp    = xtxt(tx, "transactionAmounts", "transactionAcquiredDisposedCode", "value")
            shares_v    = safe_float(
                xtxt(tx, "transactionAmounts", "transactionShares", "value")
                or xtxt(tx, "underlyingSecurity", "underlyingSecurityShares", "value")
            )
            price_v     = safe_float(xtxt(tx, "transactionAmounts", "transactionPricePerShare", "value"))
            exercise_px = safe_float(xtxt(tx, "conversionOrExercisePrice", "value"))
            owned_after = safe_float(xtxt(tx, "postTransactionAmounts", "sharesOwnedFollowingTransaction", "value"))
            dir_indir   = xtxt(tx, "ownershipNature", "directOrIndirectOwnership", "value")
            fn_txt      = resolve_fn(tx)

            if tx_code in ("P", "X", "M", "C"):     tx_type = "buy"
            elif tx_code in ("S", "D", "F", "H", "E"): tx_type = "sell"
            elif acq_disp == "A":                    tx_type = "buy"
            elif acq_disp == "D":                    tx_type = "sell"
            else:                                    tx_type = "other"

            eff_price = price_v if price_v is not None else exercise_px
            value     = round(shares_v * eff_price, 2) if shares_v and eff_price else None
            transactions.append(Transaction(
                **base(),
                transaction_date       = tx_date,
                transaction_type       = tx_type,
                transaction_code       = tx_code,
                transaction_code_label = TX_CODE_MAP.get(tx_code or "", "Other"),
                is_derivative          = True,
                security_title         = security,
                shares                 = shares_v,
                price_per_share        = eff_price,
                value                  = value,
                shares_owned_after     = owned_after,
                direct_ownership       = (dir_indir or "D") == "D",
                footnotes              = fn_txt,
            ))

    return transactions

# ── Worker ─────────────────────────────────────────────────────────────────────

def process_one(meta: dict) -> tuple[str, list[Transaction]]:
    accession = meta["accession"]
    cik       = meta["cik"]
    xml_url   = get_xml_url(accession, cik)
    if not xml_url:
        return accession, []
    time.sleep(POLITE_SLEEP)
    xml_text = fetch_xml(xml_url)
    if not xml_text:
        return accession, []
    txns = parse_form4_xml(xml_text, accession, cik,
                           fallback_date    = meta.get("file_date"),
                           fallback_company = meta.get("entity_name"))
    return accession, txns

# ── Neon/Postgres upsert ──────────────────────────────────────────────────────

UPSERT_SQL = f"""
INSERT INTO public.filings ({", ".join(COLUMNS)})
VALUES ({", ".join(["%s"] * len(COLUMNS))})
ON CONFLICT (accession_number, transaction_date, shares, transaction_code)
DO UPDATE SET
    company_name           = EXCLUDED.company_name,
    ticker                 = EXCLUDED.ticker,
    insider_name           = EXCLUDED.insider_name,
    insider_title          = EXCLUDED.insider_title,
    transaction_type       = EXCLUDED.transaction_type,
    transaction_code_label = EXCLUDED.transaction_code_label,
    price_per_share        = EXCLUDED.price_per_share,
    value                  = EXCLUDED.value,
    shares_owned_after     = EXCLUDED.shares_owned_after,
    sector                 = EXCLUDED.sector,
    relationship           = EXCLUDED.relationship,
    footnotes              = EXCLUDED.footnotes,
    updated_at             = now()
"""

def upsert_to_neon(transactions: list[Transaction], batch_size: int = 500) -> int:
    conn = get_connection()
    written = 0
    try:
        with conn:
            cur = conn.cursor()
            for i in range(0, len(transactions), batch_size):
                batch = transactions[i : i + batch_size]
                rows  = [t.to_tuple() for t in batch]
                cur.executemany(UPSERT_SQL, rows)
                written += len(batch)
                log.info(f"  Batch {i // batch_size + 1}: {len(batch)} rows written ({written} total)")
    finally:
        conn.close()
    return written

# ── Main ──────────────────────────────────────────────────────────────────────

def run() -> None:
    if not DRY_RUN and not DATABASE_URL:
        log.error("DATABASE_URL not set. Copy db/.env.example to db/.env and fill it in.")
        sys.exit(1)

    end_date   = END_DATE_OVERRIDE   or date.today().isoformat()
    start_date = START_DATE_OVERRIDE or (date.today() - timedelta(days=DAYS_BACK)).isoformat()

    log.info("═" * 62)
    log.info("  SEC Form 4 → Neon Postgres Ingestion")
    log.info(f"  Range    : {start_date}  →  {end_date}")
    log.info(f"  Workers  : {MAX_WORKERS}   Dry run: {DRY_RUN}")
    log.info("═" * 62)

    # 1. Discover
    log.info("Step 1/3  Querying EDGAR EFTS…")
    meta_list = edgar_get_accessions(start_date, end_date)
    log.info(f"          {len(meta_list)} filings to process")
    if not meta_list:
        log.info("Nothing to do.")
        return

    # 2. Fetch + parse
    log.info(f"Step 2/3  Downloading + parsing XML ({MAX_WORKERS} threads)…")
    all_txns: list[Transaction] = []
    failed = 0

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
        futures = {pool.submit(process_one, m): m for m in meta_list}
        for i, fut in enumerate(as_completed(futures), 1):
            try:
                _, txns = fut.result()
                all_txns.extend(txns)
            except Exception as e:
                failed += 1
                log.warning(f"  {futures[fut]['accession']}: {e}")
            if i % 100 == 0 or i == len(meta_list):
                log.info(f"  {i}/{len(meta_list)} filings — {len(all_txns)} transactions so far")

    log.info(f"          {len(all_txns)} transactions parsed; {failed} filings failed")
    if not all_txns:
        log.info("Nothing to write.")
        return

    # 3. Write
    if DRY_RUN:
        log.info("Step 3/3  DRY RUN — sample row:")
        log.info(json.dumps(asdict(all_txns[0]), indent=4, default=str))
    else:
        log.info("Step 3/3  Upserting to Neon…")
        total = upsert_to_neon(all_txns)
        log.info(f"          {total} rows written ✓")

    log.info("═" * 62)
    log.info("Done.")

if __name__ == "__main__":
    run()
